let Images = { // Inicia um objeto com o nome Images e utilizando { e deve terminar com }
       "0": new Image("assets/0.png", RAM), // não pode ter nome repetido e vc deve utilizar , no final para separar os objetos
       "1": new Image("assets/1.png", RAM),
       "2": new Image("assets/2.png", RAM),
       "3": new Image("assets/3.png", RAM),
       "4": new Image("assets/4.png", RAM),
       "5": new Image("assets/5.png", RAM),
       "6": new Image("assets/6.png", RAM),
       "7": new Image("assets/7.png", RAM),
       "8": new Image("assets/8.png", RAM),
       "9": new Image("assets/9.png", RAM),
       "10": new Image("assets/10.png", RAM),
       "11": new Image("assets/11.png", RAM),
       "12": new Image("assets/12.png", RAM),
       "13": new Image("assets/13.png", RAM),
       "14": new Image("assets/14.png", RAM),
       "15": new Image("assets/15.png", RAM),
       "16": new Image("assets/16.png", RAM),
       "17": new Image("assets/17.png", RAM),
       "18": new Image("assets/18.png", RAM),
       "19": new Image("assets/19.png", RAM),
       "20": new Image("assets/20.png", RAM),
       "21": new Image("assets/21.png", RAM),
       "22": new Image("assets/22.png", RAM),
       "23": new Image("assets/23.png", RAM),
       "24": new Image("assets/24.png", RAM),
       "25": new Image("assets/25.png", RAM),
       "26": new Image("assets/26.png", RAM),
       "27": new Image("assets/27.png", RAM),
       "28": new Image("assets/28.png", RAM),
       "29": new Image("assets/29.png", RAM),
       "30": new Image("assets/30.png", RAM),
       "31": new Image("assets/31.png", RAM),
       "32": new Image("assets/32.png", RAM),
       "33": new Image("assets/33.png", RAM),
       "34": new Image("assets/34.png", RAM),
       "35": new Image("assets/35.png", RAM),
       "36": new Image("assets/36.png", RAM),
       "37": new Image("assets/37.png", RAM),
       "38": new Image("assets/38.png", RAM),
       "39": new Image("assets/39.png", RAM),
       "40": new Image("assets/40.png", RAM),
       "41": new Image("assets/41.png", RAM),
       "42": new Image("assets/42.png", RAM),
       "43": new Image("assets/43.png", RAM),
       "44": new Image("assets/44.png", RAM),
       "45": new Image("assets/45.png", RAM),
       "46": new Image("assets/46.png", RAM),
       "47": new Image("assets/47.png", RAM),
       "48": new Image("assets/ciclo0.png", RAM),
       "49": new Image("assets/ciclo1.png", RAM),
       "50": new Image("assets/ciclo2.png", RAM),
       "51": new Image("assets/ciclo3.png", RAM),
       "52": new Image("assets/ciclo4.png", RAM),
       "53": new Image("assets/ciclo5.png", RAM),
       "54": new Image("assets/ciclo6.png", RAM),
}

Sound.setVolume(100, 1);
var audio = Sound.load("assets/TitleScreen.ogg"); // carrega o som
Sound.play(audio, 1); // utlizando o audio ele da um play no audio

let frame = 0 // Uma variavel que indica em qual frame está
let Time = Timer.new() // Cria um novo timer
let tempoFrame = 2000 / 54 // Uma equação de 1000 milesegundos dividido por 56 frames para fazer um delay nos frames para durar um segundo

function MostrarSonic() { // Função de animação que fiz
  const time = Timer.getTime(Time)
  if (time > tempoFrame) { // Se o time for maior que o delay então ele vai mudar o frame
     frame++ // adiciona um frame
     if (frame == 48) {
      tempoFrame = 3000 / 54
     }
     if (frame > 54) { // Se passar do ultimo frame(47) ele volta pro 48
          frame = 48
     }
     Timer.setTime(Time, 0)
  }
  Images[frame].draw(100, 100) // Acessa o objetos imagens no numero do frame e desenha no x 100 e y 100
}

while (true) {
   Screen.clear()
   MostrarSonic()
   Screen.flip()
}